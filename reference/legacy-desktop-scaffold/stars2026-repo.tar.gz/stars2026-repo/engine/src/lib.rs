//! Stars 2026 — Game Engine
//!
//! A ground-up reimplementation of the classic Stars! (1995) 4X strategy game.
//! This crate contains all game logic and compiles to WebAssembly for browser use.

pub mod types;

// Future modules (uncomment as they are implemented):
// pub mod galaxy;
// pub mod race;
// pub mod planet;
// pub mod tech;
// pub mod ship;
// pub mod fleet;
// pub mod combat;
// pub mod turn;
// pub mod scanner;
